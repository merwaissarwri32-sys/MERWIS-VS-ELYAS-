MERWIS VS ELYAS — NEON TACTICAL DUEL

LAUNCH: Extract the ZIP and open MERWIS-VS-ELYAS/index.html in any modern browser. Fully offline, nothing to install.

CONTROLS
Mouse/touch: tap MOVE, then a glowing marker. Pick WALL then aim and click (touch: tap to aim, tap again to place).
Keyboard: 1 = move, 2 = horizontal wall, 3 = vertical wall, arrows + Enter to place, Esc closes help.

GAMEPLAY
Two players share one screen. MERWIS (cyan) races to the top row, ELYAS (magenta) to the bottom row.
Each turn: move one square (jump over an adjacent opponent when legal) OR place one of your 10 walls.
Walls may never completely block a player's route. First to reach the goal row wins.
